/*
 * Topic 3 Programming Assignment: Computational Theory
 * Reads a user file of a DFA and checks user strings if they are 
 * accepted or rejected in the DFA language. 
 * Assumes that all input files are DFAs 
 */
package finiteautomata;

import java.util.ArrayList;
import javax.swing.JFileChooser;
import java.io.IOException;
import java.io.FileInputStream;
import java.util.Scanner;
import javax.swing.filechooser.FileSystemView;
import javax.swing.JOptionPane; 

/**
 * @author Julia Masciarelli
 * 27th August, 2020
 */
public class FiniteAutomata {
    private static String startState;
    private static ArrayList<String> acceptStates = new ArrayList<>();
    private static ArrayList<Character> alphabet = new ArrayList<>();
    private static ArrayList<String> states = new ArrayList<>();
    private static ArrayList<Transistion> transistions = new ArrayList<>();
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        FileInputStream fileByteStream = null;
        Scanner inFS = null; 
        String userFile = getUserFile();
        
        
        //Reads file and extracts DFA information
        fileByteStream = new FileInputStream(userFile);
        inFS = new Scanner(fileByteStream);
        
        startState = inFS.nextLine();
        
        String [] acceptStatesLine = inFS.nextLine().split(" "); 
        for (int i = 0; i < acceptStatesLine.length; i++) {
            acceptStates.add(acceptStatesLine[i]);
        }
        
        while(inFS.hasNext()){ 
            String [] transitionLine = inFS.nextLine().split(" ");
            String fromState = transitionLine[0];
            char label = transitionLine[1].charAt(0);
            String toState = transitionLine[2];
            
            Transistion transistion = new Transistion(fromState, label, toState);
            transistions.add(transistion);
            
            /* 
             * Check to see if a state or alphabet label has already been 
             * read in the file before adding to list 
             * Complexity on .contains()  is O(n) 
             */
            if(!alphabet.contains(label)) {
                alphabet.add(label);
            }
            if(!states.contains(fromState)) {
                states.add(fromState);
            }
            if(!states.contains(toState)) {
                states.add(toState);
            }
           
        }
        
        fileByteStream.close(); 
        
        displayAlphabet();
        
        /*
         * Opens GUI to prompt user for a string and displays if the string is
         * either an accepted or a rejected string for the DFA
         */
        String userInput = JOptionPane.showInputDialog("Enter DFA String");
        if(isAcceptedString(userInput)) {
            System.out.println("ACCEPTED STRING");
        }
        else {
            System.out.println("REJECTED STRING");
        }
        
    }
    
    
    /**
     *
     * Displays alphabet for the DFA
     * 
     */
    public static void displayAlphabet() {
        System.out.print("DFA Alphabet: {");
        for(int i = 0; i < alphabet.size(); i++) { 
            System.out.print(alphabet.get(i));
            if(i != alphabet.size() - 1) {
                System.out.print(",");
            }
        }
        System.out.println("}");
    }
    
    /**
     * 
     * @return selected file from JFileChooser
     */
    public static String getUserFile() {
        
        /* JFileChooser code from Mkyong.com 
         * https://mkyong.com/swing/java-swing-jfilechooser-example/
         */
        JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        int returnValue = jfc.showOpenDialog(null); 
        
        if(returnValue == JFileChooser.APPROVE_OPTION) { 
            String selectedFile = jfc.getSelectedFile().getAbsolutePath();
            return selectedFile;
        }
        
        return null; 
    }
    
    /**
     * Checks to ensure string is a member of the DFA language
     * Complexity: O(n^2 + n) where n is string length and ArrayList has no 
     * way to random access elements 
     * @param userInput DFA string from user
     * @return boolean true or false is string is accepted
     */
    public static boolean isAcceptedString(String userInput) { 
        String currState = startState;
        char currTransition; 
        
        for (int i = 0; i < userInput.length(); i++) { 
            currTransition = userInput.charAt(i); 
            
            for(int j = 0; j < transistions.size(); j++) { 
                
                if(transistions.get(j).getFromState().equals(currState) 
                        && transistions.get(j).getLabel() == currTransition) { 
                    currState = transistions.get(j).getToState();
                    break; 
                }
            }
        }
            
        /*
         * If the string is an accepted string, the end state should be an 
         * accept state, thereofore currState should equal one of the accept 
         * states. 
         */
        if(acceptStates.contains(currState)) { 
            return true;
        }
        else {
           return false;
        }
    }
    
}

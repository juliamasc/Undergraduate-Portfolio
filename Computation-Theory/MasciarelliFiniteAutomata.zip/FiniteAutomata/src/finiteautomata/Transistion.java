/*
 * Transiston Object Class 
 */
package finiteautomata;

import java.util.Objects;

/**
 * @author Julia Masciarelli
 */
public class Transistion {
    public String fromState; 
    public char label;
    public String toState;
    
    public Transistion(String fromState, char label, String toState) {
        this.fromState = fromState;
        this.label = label;
        this.toState = toState;
    }
    
    @Override
    public String toString() { 
        return "From State " + fromState + " Label " + label + " toState "
                + toState; 
    }
    /**
     * equals method that is used to compare transitions 
     */
    public boolean equals(Transistion t) { 
        if (t.fromState.equals(fromState) && t.label == label &&
                t.toState.equals(toState)) { 
            return true;
        }
        else {
            return false;
        }
    }
    
    
    public String getFromState() {
        return fromState;
    }

    public char getLabel() {
        return label;
    }

    public String getToState() {
        return toState;
    }
    
}



/*
 * Transistion Class for PDA (5 Tuple) 
 */
package pushdownautomata;

/**
 *
 * @author Julia Masciarelli
 */
public class Transistion {
    public String fromState; 
    public char input;
    public char stackPop; 
    public char stackPush;
    public String toState; 
 
    public Transistion(String fromState, char input, char stackPop, 
            char stackPush, String toState) { 
        this.fromState = fromState;
        this.input = input;
        this.stackPop = stackPop;
        this.stackPush = stackPush;
        this.toState = toState; 
    }
    
    public boolean equals(Transistion t) { 
        return true;
    }

    public String getFromState() {
        return fromState;
    }

    public char getInput() {
        return input;
    }

    public char getStackPop() {
        return stackPop;
    }

    public char getStackPush() {
        return stackPush;
    }

    public String getToState() {
        return toState;
    }
    
    
}

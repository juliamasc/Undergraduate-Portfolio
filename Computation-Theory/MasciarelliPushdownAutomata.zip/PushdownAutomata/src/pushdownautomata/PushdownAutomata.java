/*
 * Pushdown Automata Main Class 
 * Takes an input file with PDA information 
 * User inputs string and program either accepts or rejects string based
 * on PDA defintion
 */
package pushdownautomata;

import java.util.ArrayList;
import javax.swing.JFileChooser;
import java.io.IOException;
import java.io.FileInputStream;
import java.util.Scanner;
import java.util.Stack;
import javax.swing.filechooser.FileSystemView;
import javax.swing.JOptionPane; 

/**
 *
 * @author Julia Masciarelli 
 * 20 September 2020
 */
public class PushdownAutomata {
    private static String startState;
    private static ArrayList<String> acceptStates = new ArrayList<>();
    private static ArrayList<Character> alphabet = new ArrayList<>();
    private static ArrayList<Transistion> transistions = new ArrayList<>();
    private static Stack<Character> pdaStack = new Stack<>();
    private static char topStack;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        FileInputStream fileByteStream = null;
        Scanner inFS = null; 
        String userFile = getUserFile();
        
        
        //Reads file and extracts PDA information
        fileByteStream = new FileInputStream(userFile);
        inFS = new Scanner(fileByteStream);
        
        startState = inFS.nextLine();
        
        String [] acceptStatesLine = inFS.nextLine().split(" "); 
        for (int i = 0; i < acceptStatesLine.length; i++) {
            acceptStates.add(acceptStatesLine[i]);
        }
        
        while(inFS.hasNextLine()) { 
            String [] transistionLine = inFS.nextLine().split(" ");
            String fromState = transistionLine[0];
            char input = transistionLine[1].substring(1).charAt(0);
            char stackTop = transistionLine[2].charAt(0);
            char stackPush = transistionLine[3].substring(0, transistionLine[3].length() - 1).charAt(0);
            String toState = transistionLine[4];
            
            Transistion transistion = new Transistion(fromState, input, stackTop, stackPush, toState);
            transistions.add(transistion);
            
            if(!alphabet.contains(input) && input != 'e') {
                alphabet.add(input);
            }
            
        }
        
        fileByteStream.close();
        
        displayAlphabet(); 
        
         /*
         * Opens GUI to prompt user for a string and displays if the string is
         * either an accepted or a rejected string for the PDA
         */
        String userInput = JOptionPane.showInputDialog("Enter PDA String");
        while(userInput != null) { 
            if(isAcceptedString(userInput)) {
                System.out.println("ACCEPTED STRING");
            }
            else {
                System.out.println("REJECTED STRING");
            }
            userInput = JOptionPane.showInputDialog("Enter PDA String");
        }
            
    }
    
     
    
    /**
     * 
     * @return selected file from JFileChooser
     */
    public static String getUserFile() {
        
        /* JFileChooser code from Mkyong.com 
         * https://mkyong.com/swing/java-swing-jfilechooser-example/
         */
        JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
        int returnValue = jfc.showOpenDialog(null); 
        
        if(returnValue == JFileChooser.APPROVE_OPTION) { 
            String selectedFile = jfc.getSelectedFile().getAbsolutePath();
            return selectedFile;
        }
        
        return null; 
    }
    
    /**
     *
     * Displays alphabet for the PDA
     *
     */
    public static void displayAlphabet() {
        System.out.print("PDA Alphabet: {");
        for(int i = 0; i < alphabet.size(); i++) { 
            System.out.print(alphabet.get(i));
            if(i != alphabet.size() - 1) {
                System.out.print(",");
            }
        }
        System.out.println("}");
    }
    
     /**
     * Checks to ensure string is a member of the PDA language
     * Complexity: 
     *            O(n) through input string
     *            O(2n) checking for valid transition
     *            O(2n^2) total complexity
     * @param userInput PDA string from user
     * @return boolean true or false is string is accepted
     */
    public static boolean isAcceptedString(String userInput) { 
        String currState = startState;
        char currTransition; 
        Transistion t;
        
        if(isInAlphabet(userInput) == false) { 
            return false; //String had characters that were not valid in alphabet
        }
        
        
        for (int i = 0; i < userInput.length(); i++) { 
            currTransition = userInput.charAt(i); 
            t = getValidTransistion(currState, currTransition); //Find transistion 
            if(t == null) {
                return false; //Invalid transistion
            }
            else { 
                if(t.getInput() == 'e') { 
                    i--; //Read nothing
                }
                if(performStackOperation(t)) { 
                    currState = t.getToState();  //Update transistion 
                }
                else { 
                    return false; //Invalid stack operation
                }
            }
        }
        
        t = getValidTransistion(currState, 'e');
        while(t != null) {      //If the string has ended but there are 'e' transistions left in PDA
            if(performStackOperation(t)) {
                currState = t.getToState();
            }
            t = getValidTransistion(currState, 'e');
        }
            
        /*
         * If the string is an accepted string, the end state should be an 
         * accept state, thereofore currState should equal one of the accept 
         * states. 
         */
        if(acceptStates.contains(currState)) //String must be empty
        { 
            return true;
        }
        else {
           return false;
        }
    } 
    
    /**
     * Ensures all values in string are in the PDA alphabet
     * @param input PDA string input
     * @return boolean true or false if string is contained in alphabet
     */
    public static boolean isInAlphabet(String input) { 
        for(int i = 0; i < input.length(); i++) {
            if(!alphabet.contains(input.charAt(i))) { 
                return false; 
            }
        }
        return true; 
    }
    
    /**
     * Ensures transition is valid part of PDA with both input or empty string
     * @param currState starting state of PDA
     * @param currTransistion input for transition
     * @return valid Transition
     */
    public static Transistion getValidTransistion(String currState, char currTransistion) { 
        for(int j = 0; j < 2; j++) { //first checks for input, then checks for 'e'
            for(int i = 0; i < transistions.size(); i++) { 
                if(transistions.get(i).getFromState().equals(currState)
                        && transistions.get(i).getInput() == currTransistion) {
                    return transistions.get(i);
                }
            }
            currTransistion = 'e';
        }
        return null; 
    }
    
    
    /**
     * Pushes or Pops values based on transition parameter
     * @param t transition that defines stack operation
     * @return boolean true if a push or pop operation was completed (false otherwise)
     */
    public static boolean performStackOperation(Transistion t){ 

        if(t.getStackPop() == 'e') { 
            pdaStack.push(t.getStackPush());
            return true; 
        }
        topStack = pdaStack.peek(); //Access top value in stack
        if(topStack == t.getStackPop()) {
            pdaStack.pop();
            return true;
        }
        else { 
            return false;
        }
        
    }
    
}

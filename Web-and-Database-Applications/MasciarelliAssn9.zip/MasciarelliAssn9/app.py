from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def home_page():
    title_name = "Home"
    return render_template('/index.html', title=title_name)


@app.route('/index')
def index_page():
    title_name = "Index"
    return render_template('/index.html', title=title_name)


@app.route('/activities')
def activities_page():
    title_name = "Activities"
    return render_template('/activities.html', title=title_name)


@app.route('/awards')
def awards_page():
    title_name = "Awards"
    if request.method == 'POST':
        return render_template('/awards.html', message="Thank you for voting!")
    else:
        return render_template('/awards.html', title=title_name)


@app.route('/meals')
def meals_page():
    title_name = "Meals"
    return render_template('/meals.html', title=title_name)


@app.route('/speakers')
def speaker_page():
    title_name = "Speakers"
    return render_template('/speakers.html', title=title_name)


@app.route('/workshops')
def workshops_page():
    title_name = "Workshops"
    return render_template('/workshops.html', title=title_name)


@app.route('/registration', methods=['POST', 'GET'])
def registration_page():

    if request.method == 'POST':
        title_name = "Thank you"
        return render_template('/thankyou.html', title=title_name)
    else:
        title_name = "Registration"
        return render_template('/registration.html', title=title_name)


if __name__ == '__main__':
    app.run()

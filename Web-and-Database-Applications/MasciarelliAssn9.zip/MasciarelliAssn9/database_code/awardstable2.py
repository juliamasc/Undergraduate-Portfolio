import sqlite3
from database_code import dbconnect


def create_awards_table(conn):
    CREATEUSER = """CREATE TABLE IF NOT EXISTS awards
                (id = INTEGER PRIMARY KEY AUTOINCREMENT,
                firstname = TEXT, 
                lastname = TEXT,
                password = TEXT)"""

    cursor = conn.cursor()
    cursor.execute(CREATEUSER)
    conn.commit()


def insert_awards_table(data):
    cursor = conn.cursor()
    INSERT = "INSERT INTO awards (nominee,description,image,votes) VALUES (?,?,?,?)"
    with open('awards.csv') as inputFile:
        lines = inputFile.readlines()
        newList = []
        for line in lines:
            lineArray = line.split(',')
            tuple = ()
            for item in lineArray:
                tuple = tuple + (item.rstrip(), )
            newList.append(tuple)
        cursor.executemany(INSERT, newList)
        conn.commit()


print("Entering Users Table")
conn = dbconnect.connect()
create_awards_table(conn)
insert_awards_table(conn)
conn.close()
print("Exiting Users Table")

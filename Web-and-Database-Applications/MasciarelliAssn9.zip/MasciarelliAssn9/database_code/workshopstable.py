import sqlite3


def connect():
    conn = sqlite3.connect('../conference.sqlite')
    conn.row_factory = sqlite3.Row
    return conn


def create_workshop_table(conn):
    CREATEWORKSHOP = """CREATE TABLE IF NOT EXISTS workshop
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                workshopname TEXT, 
                workshoptime INTEGER,
                room TEXT,
                starttime TEXT,
                endtime TEXT);"""

    cursor = conn.cursor()
    cursor.execute(CREATEWORKSHOP)
    conn.commit()


def insert_workshop_table(data):
    cursor = conn.cursor()
    with open('workshops.csv') as inputFile:
        for line in inputFile:
            lineArray = line.split(',')
            INSERT = "INSERT INTO workshop (workshopname,workshoptime,room,starttime,endtime) VALUES ('" \
                     + lineArray[0] + "','" + lineArray[1] + "','" + lineArray[2] + "','" +\
                     lineArray[3] + "','" + lineArray[4] + "')"
            cursor.execute(INSERT)
            conn.commit()


print("Entering Workshop Table")
conn = connect()
create_workshop_table(conn)
insert_workshop_table(conn)
conn.close()
print("Exiting Workshop Table")

import sqlite3


def connect():
    conn = sqlite3.connect('../conference.sqlite')
    conn.row_factory = sqlite3.Row
    return conn

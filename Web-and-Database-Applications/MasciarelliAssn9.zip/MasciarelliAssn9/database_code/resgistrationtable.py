import sqlite3
#from database_code import dbconnect


def connect():
    conn = sqlite3.connect('../conference.sqlite')
    conn.row_factory = sqlite3.Row
    return conn

def create_registration_table(conn):
    CREATEREGISTRATION = """CREATE TABLE IF NOT EXISTS registration
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT,
                firstname TEXT,
                lastname TEXT,
                address1 TEXT,
                address2 TEXT,
                city TEXT,
                state TEXT,
                zip INTEGER,
                phone TEXT,
                email TEXT,
                website TEXT,
                cposition TEXT,
                comapny TEXT,
                meal INTEGER,
                billfirstname TEXT,
                billlastname TEXT,
                cardtype INTEGER,
                cardnumber TEXT,
                csv INTEGER,
                expyear INTEGER,
                expmonth INTEGER,
                workshops INTEGER);"""
    cursor = conn.cursor()
    cursor.execute(CREATEREGISTRATION)
    conn.commit()


def insert_registration_table(data):
    cursor = conn.cursor()
    INSERT = "INSERT INTO registration(title,firstname,lastname,address1,address2,city,state,zip,phone,email,website,cposition,comapny,meal,billfirstname,billlastname,cardtype,cardnumber,csv,expyear,expmonth,workshops)" \
             "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    with open('registration.csv') as inputFile:
        lines = inputFile.readlines()
        newlist = []
        for line in lines:
            line_array = line.split(',')
            tuple = ()
            for item in line_array:
                tuple = tuple + (item.rstrip(),)
            newlist.append(tuple)
            print(newlist)
        cursor.executemany(INSERT, newlist)
        conn.commit()


print("Entering Registration Table")
conn = connect()
create_registration_table(conn)
insert_registration_table(conn)
conn.close()
print("Exiting Registration Table")

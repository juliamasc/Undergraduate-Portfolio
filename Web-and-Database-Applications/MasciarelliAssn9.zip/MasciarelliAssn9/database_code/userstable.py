import sqlite3


def connect():
    conn = sqlite3.connect('../conference.sqlite')
    conn.row_factory = sqlite3.Row
    return conn


def create_user_table(conn):
    CREATEUSER = """CREATE TABLE IF NOT EXISTS user
                (id INTEGER PRIMARY KEY AUTOINCREMENT,
                firstname TEXT, 
                lastname TEXT,
                password TEXT);"""

    cursor = conn.cursor()
    cursor.execute(CREATEUSER)
    conn.commit()


def insert_user_table(data):
    cursor = conn.cursor()
    with open('users.csv') as inputFile:
        for line in inputFile:
            lineArray = line.split(',')
            INSERT = "INSERT INTO user (firstname,lastname,password) VALUES ('" + lineArray[0] + "','" + lineArray[1] + "','" + lineArray[2] + "')"
            cursor.execute(INSERT)
            conn.commit()


print("Entering Users Table")
conn = connect()
create_user_table(conn)
insert_user_table(conn)
conn.close()
print("Exiting Users Table")


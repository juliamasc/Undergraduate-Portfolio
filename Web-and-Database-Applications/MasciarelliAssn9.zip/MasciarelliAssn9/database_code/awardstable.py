import sqlite3


def connect():
    conn = sqlite3.connect('../conference.sqlite')
    conn.row_factory = sqlite3.Row
    return conn


def create_awards_table(conn):
    CREATEAWARDS = """CREATE TABLE IF NOT EXISTS awards
                (id  INTEGER PRIMARY KEY AUTOINCREMENT,
                nominee TEXT, 
                description TEXT,
                image TEXT,
                votes TEXT)"""

    cursor = conn.cursor()
    cursor.execute(CREATEAWARDS)
    conn.commit()


def insert_awards_table(data):
    cursor = conn.cursor()
    with open('awards.csv') as inputFile:
        for line in inputFile:
            lineArray = line.split(',')
            INSERT = "INSERT INTO awards (nominee,description,image,votes) VALUES ('" + lineArray[0] + "','" + lineArray[1] + "','" + lineArray[2] + "','" + lineArray[3] + "')"
            cursor.execute(INSERT)
            conn.commit()


print("Entering Awards Table")
conn = connect()
create_awards_table(conn)
insert_awards_table(conn)
conn.close()
print("Exiting Awards Table")


/*
 * RegisResQ Main Class 
 * A program used to keep track of animals at the RegisResQ shelter
 */
package regisresq;

/**
 *
 * @author Julia
 * 
 */

import regisresq.persistence.*;
import regisresq.application.*;
import regisresq.presentation.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.*;
public class RegisResQ {

    /**
     * Calls MainUI
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        new MainUI().setVisible(true);
    }
    
}

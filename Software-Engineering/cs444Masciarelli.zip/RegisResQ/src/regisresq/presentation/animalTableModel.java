/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package regisresq.presentation;
import java.util.List;
import regisresq.application.animal;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Julia
 */
public class animalTableModel extends AbstractTableModel {
    
    private List<animal> animals;
    private String[] columnNames = {"Type", 
                                    "Breed",
                                    "Name", 
                                    "Sterilized", 
                                    "Arrived"};

    public animalTableModel() {
        animals = null;
    }

    public void setAnimals(List<animal> animals) {
        this.animals = animals;
    }
    
    @Override
    public int getRowCount() { 
        return animals.size();
    }
    
    @Override 
    public int getColumnCount() { 
        return columnNames.length;
    }
    
    @Override
    public Object getValueAt(int row, int column) { 
        animal a;
        a = animals.get(row);
        
        switch(column) { 
            case 0:
                return a.getSpecies();
            case 1: 
                return a.getBreed();
            case 2:
                return a.getName();
            case 3: 
                return a.getSterilized();
            case 4: 
                return a.getDateArrived(); 
            default: 
                return "";
        }     
        
    }
    
}
    
    
    
    
    


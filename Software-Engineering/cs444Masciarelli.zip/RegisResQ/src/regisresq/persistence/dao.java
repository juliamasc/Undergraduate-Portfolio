/*
 * Dao Interface
 * 
 */
package regisresq.persistence;

import java.util.*;

/**
 *
 * @author Julia Masciarelli
 */
public interface dao<T> {
    List<T> getAll(); 
    
    Boolean add(T item); 
    
    Boolean update(T item);
    
    Boolean delete(T item);
}

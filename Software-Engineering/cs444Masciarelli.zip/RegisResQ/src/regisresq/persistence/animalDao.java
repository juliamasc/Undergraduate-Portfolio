/*
 * Animal Dao Class 
 * Implements the Dao interface to connect to the mySQL database 
 * Used to add, delete, modify and display animals in the database
 */
package regisresq.persistence;

import regisresq.application.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.*;

/**
 *
 * @author Julia Masciarelli
 */
public class animalDao implements dao<animal> {
    private ArrayList<animal> animals;
    private Connection connection = null;
    private Statement statement = null;
    private ResultSet resultSet = null;
    
    
    /**
     * Default Constructor for animalDao 
     */
    public animalDao() { 
        animals = new ArrayList<animal>(); 
        try { 
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/animals",
                    "cs444", "p@sswordCS444");
            
        }
        catch(ClassNotFoundException cnfe) { 
            System.err.print("Error: " + cnfe);
        }
        catch(SQLException sqle) { 
            System.err.print("Error: " + sqle);
        }
    }
    /**
     * Gets all animals stored in the SQL database and puts them into
     * the animals list
     * @return animals list
     */
    public ArrayList<animal> getAll() { 
        animal a = null;
        animals = new ArrayList<animal>();
        boolean isSterilized;
        
        try { 
            statement = connection.createStatement();
            resultSet = statement.executeQuery("select * from adoptable_pets;");
            
            while(resultSet.next()) {
                if(resultSet.getString("sterilized").equals("1")) { 
                    isSterilized = true; 
                }
                else { 
                    isSterilized = false;
                }
                
                if(resultSet.getString("type").equals("cat")) { 
                    a = new cat(resultSet.getString("breed"),
                            resultSet.getString("name"), isSterilized, 
                            resultSet.getString("arrived"));
                }
                else { 
                    if(resultSet.getString("type").equals("dog")) { 
                        a = new dog(resultSet.getString("breed"),
                            resultSet.getString("name"), isSterilized, 
                            resultSet.getString("arrived"));
                    }
                }
                animals.add(a);
            }


        }
        catch(SQLException sqle) { 
            System.err.print("Error: " + sqle);
        }
        return animals;
    }
    
    
    /**
     * Adds an animal to the SQL database
     * @param a: animal added to database
     * @return boolean true is added or false if there is an error
     */
    public Boolean add(animal a) { 
        String type = null; 
        try { 
            statement = connection.createStatement();
            if(a.getSpecies().equals("dog")) { 
                type = "dog";
            }
            else { 
                if(a.getSpecies().equals("cat")) { 
                    type = "cat";
                }
            }
            
            statement.execute("insert into adoptable_pets (type, breed, name, sterilized, arrived) values ('" 
                    + a.getSpecies() + "', '" + a.getBreed() + "', '" + a.getName() + "', " 
                    + String.valueOf(a.getSterilized()) + ", '"  //Does there need to be single quotes around getSterilized? 
                    + a.getDateArrived() + "');");
            return true;
        } catch(SQLException sqle) { 
            System.err.print("Error: " + sqle);
            return false;
        }
    }
    /** 
     * Updates animal value in SQL Database
     * @param a: animal to be updated
     * @return boolean value true if update is successful and false otherwise
     */
    public Boolean update(animal a) { 
        try { 
            statement = connection.createStatement();
            statement.executeUpdate("update adoptable_pets set type = '" 
                    + a.getSpecies() + "', breed = '" + a.getBreed() + "', sterilized = "
                    + String.valueOf(a.getSterilized()) 
                    + ", arrived = '" + a.getDateArrived() + "' where name = '" 
                    + a.getName() + "';");
            return true;
        } catch(SQLException sqle) { 
            System.err.print("Error: "  + sqle);
            return false;
        }
    }
    
    /**
     * Deletes animal from SQL database
     * @param a: animal to be deleted
     * @return boolean value true is delete is successful and false otherwise
     */
    public Boolean delete(animal a) { 
        try { 
            statement = connection.createStatement();
            statement.executeUpdate("delete from adoptable_pets where name ='" + a.getName() + "';");
            return true;
        } catch(SQLException sqle) { 
            System.err.print("Error: " + sqle);
            return false;
        }
    }
}

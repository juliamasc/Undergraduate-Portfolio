/*
 * Animal Abstract Class
 * This class is the animal super class for all animals at the rescue
 * The class has getter and setter methods for the variables associated with 
 * animal as well as 2 constructors
 */
package regisresq.application;

/**
 *
 * @author Julia
 */
public abstract class animal {
    protected String species;
    protected String breed;
    protected String name;
    protected boolean sterilized;
    protected String dateArrived;

    
    /** 
     * Default constructor - set all values to null/false
     */
    public animal() {
        species = null;
        breed = null;
        name = null;
        sterilized = false;
        dateArrived = null;
    }

    /**
     * Constructor with specific values for input parameters
     * @param species - String animal species
     * @param breed - String animal breed
     * @param name - String animal name
     * @param sterilized - Boolean is animal sterilized
     * @param dateArrived - String dateArrived
     */
    public animal(String species, String breed, String name, boolean sterilized, String dateArrived) {
        this.species = species;
        this.breed = breed;
        this.name = name;
        this.sterilized = sterilized;
        this.dateArrived = dateArrived;
    }
    
    /**
     * Validates the date formatting and returns if it is correctly formatted or not
     * Correct date format (YYYY-MM-DD)
     * @return Boolean is formatted correctly
     */
    public boolean validate() {
        if(breed == null || breed.isEmpty()) {
            return false;
        }
        if(name == null || name.isEmpty()) { 
            return false;
        }
        if(dateArrived == null || dateArrived.isEmpty()) { 
            return false;
        }
        
        if(dateArrived.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
            String[] splitDate = dateArrived.split("-");
            String yearString = splitDate[0];
            int year = Integer.parseInt(yearString);
            String monthString = splitDate[1];
            int month = Integer.parseInt(monthString);
            String dayString = splitDate[2];
            int day = Integer.parseInt(dayString);
           
            switch(month) { 
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12: 
                    return(day <= 31);
                case 2:
                    return(day <= 29);
                case 4:
                case 6:
                case 9:
                case 11:
                    return(day <= 30);
                default:
                    return false;
            }
        }
        return false; 
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isSterilized() {
        return sterilized;
    }
    
    public boolean getSterilized() { 
        return sterilized;
    }

    public void setSterilized(boolean sterilized) {
        this.sterilized = sterilized;
    }

    public String getDateArrived() {
        return dateArrived;
    }

    public void setDateArrived(String dateArrived) {
        this.dateArrived = dateArrived;
    }

    @Override
    public String toString() {
        return "animal{" + "species=" + species + ", breed=" + breed + ", name=" + name + ", sterilized=" + sterilized + ", dateArrived=" + dateArrived + '}';
    }
    
    
    
}

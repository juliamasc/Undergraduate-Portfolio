/*
 * Dog Class - extends Abstract class animal
 * An animal class for doga, with constructors to set species as 'dog'
 */
package regisresq.application;

/**
 *
 * @author Julia
 */
public class dog extends animal {
    
    String breed;
    String name;
    boolean sterilized;
    String dateArrived; 
    
    /**
     * Default constructor 
     * Uses super class animal constructor and sets species as 'dog'
     */
    public dog() { 
        super();
        super.setSpecies("dog");
    }
    
    /** 
     * Dog constructor with parameter values
     * sets species as 'dog'
     * @param breed - String dog breed
     * @param name - String dog name
     * @param sterilized - Boolean is dog is sterilized or not
     * @param dateArrived - String date (formatted YYYY-MM-DD) of animal's arrival date
     */
    public dog(String breed, String name, boolean sterilized, String dateArrived) { 
        super("dog", breed, name, sterilized, dateArrived);
    }
    
    
}

/*
 * Cat Class - extends Abstract class animal
 * An animal class for cats, with constructors to set species as 'cat'
 */
package regisresq.application;

/**
 *
 * @author Julia
 */
public class cat extends animal {
    String breed;
    String name;
    boolean sterilized;
    String dateArrived;
    
    
    /**
     * Default constructor 
     * Uses super class animal constructor and sets species as 'cat'
     */
    public cat() { 
        super();
        super.setSpecies("cat");
    }
    
    
    /** 
     * Cat constructor with parameter values
     * sets species as 'cat'
     * @param breed - String cat breed
     * @param name - String cat name
     * @param sterilized - Boolean is cat is sterilized or not
     * @param dateArrived - String date (formatted YYYY-MM-DD) of animal's arrival date
     */
    public cat(String breed, String name, boolean sterilized, String dateArrived) { 
        super("cat", breed, name, sterilized, dateArrived);
    }
}

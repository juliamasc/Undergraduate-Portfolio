/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package regisresq.application;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 *
 * @author Julia
 */
public class animalNGTest {
    
    public animalNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    /**
     * Test of validate method, of class animal.
     */
    @Test
    public void testValidate() {
        System.out.println("validate");
        animal instance = new animalImpl();
        boolean expResult = false;
        boolean result = instance.validate();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSpecies method, of class animal.
     */
    @Test
    public void testGetSpecies() {
        System.out.println("getSpecies");
        animal instance = new animalImpl();
        String expResult = "";
        String result = instance.getSpecies();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSpecies method, of class animal.
     */
    @Test
    public void testSetSpecies() {
        System.out.println("setSpecies");
        String species = "";
        animal instance = new animalImpl();
        instance.setSpecies(species);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getBreed method, of class animal.
     */
    @Test
    public void testGetBreed() {
        System.out.println("getBreed");
        animal instance = new animalImpl();
        String expResult = "";
        String result = instance.getBreed();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setBreed method, of class animal.
     */
    @Test
    public void testSetBreed() {
        System.out.println("setBreed");
        String breed = "";
        animal instance = new animalImpl();
        instance.setBreed(breed);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getName method, of class animal.
     */
    @Test
    public void testGetName() {
        System.out.println("getName");
        animal instance = new animalImpl();
        String expResult = "";
        String result = instance.getName();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setName method, of class animal.
     */
    @Test
    public void testSetName() {
        System.out.println("setName");
        String name = "";
        animal instance = new animalImpl();
        instance.setName(name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isSterilized method, of class animal.
     */
    @Test
    public void testIsSterilized() {
        System.out.println("isSterilized");
        animal instance = new animalImpl();
        boolean expResult = false;
        boolean result = instance.isSterilized();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSterilized method, of class animal.
     */
    @Test
    public void testSetSterilized() {
        System.out.println("setSterilized");
        boolean sterilized = false;
        animal instance = new animalImpl();
        instance.setSterilized(sterilized);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDateArrived method, of class animal.
     */
    @Test
    public void testGetDateArrived() {
        System.out.println("getDateArrived");
        animal instance = new animalImpl();
        String expResult = "";
        String result = instance.getDateArrived();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDateArrived method, of class animal.
     */
    @Test
    public void testSetDateArrived() {
        System.out.println("setDateArrived");
        String dateArrived = "";
        animal instance = new animalImpl();
        instance.setDateArrived(dateArrived);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class animal.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        animal instance = new animalImpl();
        String expResult = "";
        String result = instance.toString();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    public class animalImpl extends animal {
    }
    
}

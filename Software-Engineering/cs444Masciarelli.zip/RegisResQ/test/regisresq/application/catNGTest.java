/*
 * Test class to ensure that the cat validate method works as expected
 */
package regisresq.application;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 *
 * @author Julia
 */
public class catNGTest {
    
    public catNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Test
    public void testValidate() {
        cat c = new cat();
        boolean result = c.validate();
        assertFalse(result);
        c.setBreed("Calico");
        result = c.validate();
        assertFalse(result);
        c.setName("Fuzzy");
        result = c.validate();
        assertFalse(result);
        c.setSterilized(true);
        result = c.validate();
        assertFalse(result);
        c.setDateArrived("Today");
        result = c.validate();
        assertFalse(result);
        c.setDateArrived("10/02/2020");
        result = c.validate();
        assertFalse(result);
        c.setDateArrived("2020/45/99");
        result = c.validate();
        assertFalse(result);
        c.setDateArrived("2020-10-02");
        result = c.validate();
        assertTrue(result);
    }
    
}

/*
 * Test Class to ensure that the dog validate method works as expected
 */
package regisresq.application;

import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 *
 * @author Julia
 */
public class dogNGTest {
    
    public dogNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Test
    public void testValidate() {
        dog c = new dog();
        boolean result = c.validate();
        assertFalse(result);
        c.setBreed("Beagle");
        result = c.validate();
        assertFalse(result);
        c.setName("Zahra");
        result = c.validate();
        assertFalse(result);
        c.setSterilized(true);
        result = c.validate();
        assertFalse(result);
        c.setDateArrived("Today");
        result = c.validate();
        assertFalse(result);
        c.setDateArrived("10/02/2020");
        result = c.validate();
        assertFalse(result);
        c.setDateArrived("2020/45/99");
        result = c.validate();
        assertFalse(result);
        c.setDateArrived("2020-10-02");
        result = c.validate();
        assertTrue(result);
    }
    
}
